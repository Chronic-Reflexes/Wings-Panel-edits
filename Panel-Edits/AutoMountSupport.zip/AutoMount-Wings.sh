#!/bin/sh
set -e

if [ -z "${WINGS_DIRECTORY:-}" ]; then
  echo "ERROR: WINGS_DIRECTORY is not set."
  echo "Usage: WINGS_DIRECTORY=/path/to/wings ./AutoMount-Wings.sh"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
WING_BACKUP_SUFFIX=".automount-backup"

find_mounts_patch() {
  if [ -n "${MOUNTS_PATCH_FILE:-}" ] && [ -f "${MOUNTS_PATCH_FILE}" ]; then
    printf '%s' "$MOUNTS_PATCH_FILE"
    return 0
  fi

  dir="$SCRIPT_DIR"
  while [ "$dir" != "/" ] && [ -n "$dir" ]; do
    candidate="$dir/.blueprint/dev/automountsupport/data/patches/mounts.patch"
    if [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
    dir="$(dirname "$dir")"
  done

  return 1
}

PATCH_FILE="$(find_mounts_patch)"
if [ $? -ne 0 ] || [ ! -f "$PATCH_FILE" ]; then
  echo "ERROR: Patch file not found. Set MOUNTS_PATCH_FILE to the correct path if needed."
  exit 1
fi

if [ -x "$WINGS_DIRECTORY/wings" ]; then
  BACKUP_FILE="$WINGS_DIRECTORY/wings$WING_BACKUP_SUFFIX"
  if [ ! -f "$BACKUP_FILE" ]; then
    cp -p "$WINGS_DIRECTORY/wings" "$BACKUP_FILE"
    echo "Backed up Wings binary to $BACKUP_FILE"
  else
    echo "Wings backup already exists at $BACKUP_FILE"
  fi
else
  echo "WARNING: Wings binary not found at $WINGS_DIRECTORY/wings. Skipping binary backup."
fi

cd "$WINGS_DIRECTORY"

if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if git apply --ignore-whitespace "$PATCH_FILE"; then
    echo "Wings patch installed successfully."
    exit 0
  fi
fi

if command -v patch >/dev/null 2>&1; then
  patch --ignore-whitespace -p1 --batch --forward < "$PATCH_FILE"
  echo "Wings patch installed successfully."
  exit 0
fi

echo "ERROR: git or patch is required to install the Wings patch."
exit 1
