#!/bin/sh
set -e

if [ -z "${WINGS_DIRECTORY:-}" ]; then
  echo "ERROR: WINGS_DIRECTORY is not set."
  echo "Usage: WINGS_DIRECTORY=/path/to/wings ./AutoMount-Wings-remove.sh"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
WING_BACKUP_SUFFIX=".automount-backup"

find_mounts_patch() {
  if [ -n "${MOUNTS_PATCH_FILE:-}" ] && [ -f "${MOUNTS_PATCH_FILE}" ]; then
    printf '%s' "$MOUNTS_PATCH_FILE"
    return 0
  fi

  if [ -n "${PTERODACTYL_DIRECTORY:-}" ]; then
    candidate="$PTERODACTYL_DIRECTORY/.blueprint/extensions/automountsupport/private/patches/mounts.patch"
    if [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  fi

  dir="$SCRIPT_DIR"
  while [ "$dir" != "/" ] && [ -n "$dir" ]; do
    candidate="$dir/.blueprint/dev/automountsupport/data/patches/mounts.patch"
    if [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
    dir="$(dirname "$dir")"
  done

  return 1
}

PATCH_FILE="$(find_mounts_patch)"
if [ $? -ne 0 ] || [ ! -f "$PATCH_FILE" ]; then
  echo "ERROR: Patch file not found. Set MOUNTS_PATCH_FILE to the correct path if needed."
  exit 1
fi

cd "$WINGS_DIRECTORY"

APPLIED=0

if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if git apply --reverse --ignore-whitespace "$PATCH_FILE"; then
    APPLIED=1
  fi
fi

if [ "$APPLIED" -eq 0 ]; then
  if command -v patch >/dev/null 2>&1; then
    patch --ignore-whitespace -p1 --batch --reverse < "$PATCH_FILE"
    APPLIED=1
  fi
fi

if [ "$APPLIED" -eq 0 ]; then
  echo "ERROR: git or patch is required to remove the Wings patch."
  exit 1
fi

BACKUP_FILE="$WINGS_DIRECTORY/wings$WING_BACKUP_SUFFIX"
if [ -f "$BACKUP_FILE" ]; then
  cp -pf "$BACKUP_FILE" "$WINGS_DIRECTORY/wings"
  rm -f "$BACKUP_FILE"
  echo "Restored Wings binary from $BACKUP_FILE"
else
  echo "WARNING: Backup file not found: $BACKUP_FILE"
fi

echo "Wings patch removed successfully."
