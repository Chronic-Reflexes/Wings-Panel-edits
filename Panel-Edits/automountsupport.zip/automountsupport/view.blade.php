@extends('layouts.admin')

@section('title')
    Auto Mount Support
@endsection

@section('content-header')
    <h1>Auto Mount Support <small>Blueprint extension information</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Auto Mount Support</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-md-8">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Extension Description</h3>
                </div>

                <div class="box-body">
                    <p>This extension adds two new mount options to the Mount edit page and applies them during server creation and reinstall.</p>

                    <ul>
                        <li><strong>Mount on Install</strong> — assign the mount automatically when a server is created or reinstalled.</li>
                        <li><strong>Auto Mount</strong> — keep the mount assigned permanently and do not remove it after install.</li>
                    </ul>

                    <h4>How it works</h4>
                    <ul>
                        <li>Uses middleware to persist the new mount fields when the Mount save form is submitted.</li>
                        <li>Uses listeners to attach mounts during server creation and install state.</li>
                        <li>Uses a migration to add the new database columns safely.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection
