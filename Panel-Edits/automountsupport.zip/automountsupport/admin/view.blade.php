@extends('layouts.admin')

@section('title')
    Auto Mount Support
@endsection

@section('content-header')
    <h1>Auto Mount Support <small>Mount auto-mount and install-time mount handling</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Auto Mount Support</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-md-8">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Extension Overview</h3>
                </div>

                <div class="box-body">
                    <p>This extension adds two new options to the Mount edit screen and applies them during server creation and reinstall.</p>

                    <ul>
                        <li><strong>Mount on Install</strong> - assign the mount during server creation or reinstall.</li>
                        <li><strong>Auto Mount</strong> - keep the mount assigned permanently and do not remove it after install.</li>
                    </ul>

                    <h4>Behavior</h4>
                    <ul>
                        <li>Persists mount settings on save via Blueprint middleware.</li>
                        <li>Assigns mounts when a server is created.</li>
                        <li>Assigns mounts again when a server enters install state.</li>
                        <li>Removes install-only mounts after install completes unless they are auto-mounted.</li>
                    </ul>

                    <h4>Implementation</h4>
                    <p>The plugin is designed for stability by avoiding core file overrides:</p>
                    <ul>
                        <li>Blueprint middleware captures Mount save form data.</li>
                        <li>Blueprint listeners handle server lifecycle events.</li>
                        <li>Database migration adds the new mount columns.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection
