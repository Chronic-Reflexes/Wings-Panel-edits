<?php

namespace Pterodactyl\Listeners;

use Pterodactyl\Models\Mount;
use Pterodactyl\Models\MountServer;
use Pterodactyl\Events\Server\Installed as ServerInstalledEvent;

class RemoveMountsAfterInstall
{
    /**
     * Handle the event.
     *
     * @param ServerInstalledEvent $event
     * @return void
     */
    public function handle(ServerInstalledEvent $event): void
    {
        $mounts = Mount::all();

        foreach ($mounts as $mount) {
            $mountOnInstall = (bool) $mount->mount_on_install;
            $autoMount = (bool) $mount->auto_mount;

            if (! $mountOnInstall || $autoMount) {
                continue;
            }

            MountServer::where('mount_id', $mount->id)
                ->where('server_id', $event->server->id)
                ->delete();
        }
    }
}
