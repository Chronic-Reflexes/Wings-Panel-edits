<?php

namespace Pterodactyl\Listeners;

use Illuminate\Support\Facades\DB;
use Pterodactyl\Events\Server\Created as ServerCreatedEvent;
use Pterodactyl\Models\Mount;

class AssignMountsToServer
{
    /**
     * Handle the event.
     *
     * @param ServerCreatedEvent $event
     * @return void
     */
    public function handle(ServerCreatedEvent $event): void
    {
        $mounts = Mount::all();

        foreach ($mounts as $mount) {
            $mountOnInstall = (bool) $mount->mount_on_install;
            $autoMount = (bool) $mount->auto_mount;

            if (! $mountOnInstall && ! $autoMount) {
                continue;
            }

            DB::table('mount_server')->updateOrInsert([
                'mount_id' => $mount->id,
                'server_id' => $event->server->id,
            ]);
        }
    }
}
