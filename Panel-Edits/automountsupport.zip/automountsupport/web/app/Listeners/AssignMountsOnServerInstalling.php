<?php

namespace Pterodactyl\Listeners;

use Illuminate\Support\Facades\DB;
use Pterodactyl\Events\Server\Saving as ServerSavingEvent;
use Pterodactyl\Models\Mount;
use Pterodactyl\Models\Server;

class AssignMountsOnServerInstalling
{
    /**
     * Handle the event.
     *
     * @param ServerSavingEvent $event
     * @return void
     */
    public function handle(ServerSavingEvent $event): void
    {
        $server = $event->server;

        if (! $server->exists) {
            return;
        }

        if (! $server->isDirty('status') || $server->status !== Server::STATUS_INSTALLING) {
            return;
        }

        $mounts = Mount::all();

        foreach ($mounts as $mount) {
            $mountOnInstall = (bool) $mount->mount_on_install;
            $autoMount = (bool) $mount->auto_mount;

            if (! $mountOnInstall && ! $autoMount) {
                continue;
            }

            DB::table('mount_server')->updateOrInsert([
                'mount_id' => $mount->id,
                'server_id' => $server->id,
            ]);
        }
    }
}
