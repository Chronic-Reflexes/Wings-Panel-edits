<?php

namespace Pterodactyl\Http\Middleware\Extensions\AutoMount;

use Closure;
use Illuminate\Support\Facades\DB;

class InterceptMountSave
{
    public function handle($request, Closure $next)
    {
        $response = $next($request);

        if ($request->routeIs('admin.mounts.view') && $request->isMethod('PATCH')) {
            $id = $request->route('mount');
            DB::table('mounts')->where('id', $id)->update([
                'mount_on_install' => $request->input('mount_on_install', 0),
                'auto_mount' => $request->input('auto_mount', 0),
            ]);
        }

        return $response;
    }
}
