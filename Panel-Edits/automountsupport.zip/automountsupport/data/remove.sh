#!/bin/sh
set -e

if [ -z "${PTERODACTYL_DIRECTORY:-}" ]; then
  echo "ERROR: PTERODACTYL_DIRECTORY is not set."
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PATCH_FILE="$SCRIPT_DIR/patches/automount-buttons.patch"

if [ ! -f "$PATCH_FILE" ]; then
  echo "ERROR: Patch file not found: $PATCH_FILE"
  exit 1
fi

cd "$PTERODACTYL_DIRECTORY"

if command -v patch >/dev/null 2>&1; then
  patch -p1 --batch --reverse < "$PATCH_FILE" || true
elif command -v git >/dev/null 2>&1; then
  git apply --reverse "$PATCH_FILE" || true
else
  echo "ERROR: git or patch is required to remove the extension patch."
  exit 1
fi
