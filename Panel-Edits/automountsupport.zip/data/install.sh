#!/bin/sh
set -e

if [ -z "${PTERODACTYL_DIRECTORY:-}" ]; then
  echo "ERROR: PTERODACTYL_DIRECTORY is not set."
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PATCH_FILE="$SCRIPT_DIR/patches/automount-buttons.patch"
WING_BACKUP_SUFFIX=".bak"

find_wings_patch() {
  if [ -n "${WING_PATCH_FILE:-}" ] && [ -f "${WING_PATCH_FILE}" ]; then
    printf '%s' "$WING_PATCH_FILE"
    return 0
  fi

  if [ -n "${PTERODACTYL_DIRECTORY:-}" ]; then
    candidate="$PTERODACTYL_DIRECTORY/.blueprint/extensions/automountsupport/private/patches/mounts.patch"
    if [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  fi

  dir="$SCRIPT_DIR"
  while [ "$dir" != "/" ] && [ -n "$dir" ]; do
    candidate="$dir/.blueprint/dev/automountsupport/data/patches/mounts.patch"
    if [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
    dir="$(dirname "$dir")"
  done

  return 1
}

WING_PATCH_FILE="$(find_wings_patch)"

ask_yes_no() {
  prompt="$1"
  default="$2"

  while true; do
    if [ -t 0 ]; then
      if [ "$default" = "Y" ]; then
        printf "%s [Y/n] " "$prompt"
      else
        printf "%s [y/N] " "$prompt"
      fi
      if ! IFS= read -r answer; then
        answer=""
      fi
    else
      answer=""
    fi

    case "$answer" in
      y|Y|yes|Yes|YES)
        return 0
        ;;
      n|N|no|No|NO)
        return 1
        ;;
      "")
        if [ "$default" = "Y" ]; then
          return 0
        fi
        return 1
        ;;
      *)
        echo "Please answer yes or no."
        ;;
    esac
  done
}

prompt_directory() {
  prompt="$1"

  while true; do
    printf "%s: " "$prompt"
    if ! IFS= read -r dir; then
      return 1
    fi
    if [ -z "$dir" ]; then
      echo "Please enter a directory path."
      continue
    fi
    if [ -d "$dir" ]; then
      printf '%s' "$dir"
      return 0
    fi
    echo "Directory does not exist: $dir"
  done
}

apply_patch_file() {
  patch_file="$1"
  if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    if git apply --ignore-whitespace "$patch_file"; then
      return 0
    fi
  fi

  if command -v patch >/dev/null 2>&1; then
    patch --ignore-whitespace -p1 --batch --forward < "$patch_file"
    return $?
  fi

  return 1
}

install_panel_patch() {
  if [ ! -f "$PATCH_FILE" ]; then
    echo "ERROR: Patch file not found: $PATCH_FILE"
    exit 1
  fi

  cd "$PTERODACTYL_DIRECTORY"

  if apply_patch_file "$PATCH_FILE"; then
    echo "Panel patch installed successfully."
  else
    echo "ERROR: git or patch is required to apply the extension patch."
    exit 1
  fi
}

install_wings_patch() {
  wings_dir="$1"
  backup_file="$wings_dir/wings$WING_BACKUP_SUFFIX"

  if [ ! -f "$WING_PATCH_FILE" ]; then
    echo "ERROR: Wings patch file not found: $WING_PATCH_FILE"
    exit 1
  fi

  if [ -x "$wings_dir/wings" ]; then
    backup_file="$wings_dir/wings$WING_BACKUP_SUFFIX"
    if [ ! -f "$backup_file" ]; then
      cp -p "$wings_dir/wings" "$backup_file"
      echo "Backed up Wings binary to $backup_file"
    else
      echo "Wings backup already exists at $backup_file"
    fi
  else
    echo "WARNING: Wings binary not found at $wings_dir/wings. Skipping binary backup."
  fi

  cd "$wings_dir"
  if apply_patch_file "$WING_PATCH_FILE"; then
    echo "Wings patch installed successfully."
  else
    echo "ERROR: git or patch is required to apply the Wings patch."
    exit 1
  fi
}

install_extension_patch_files() {
  ext_dir="$PTERODACTYL_DIRECTORY/.blueprint/extensions/automountsupport/private/patches"

  if [ ! -d "$ext_dir" ]; then
    echo "NOTE: Blueprint did not create $ext_dir yet; skipping patch file copy."
    return 0
  fi

  if [ -f "$SCRIPT_DIR/patches/automount-buttons.patch" ]; then
    cp -f "$SCRIPT_DIR/patches/automount-buttons.patch" "$ext_dir/"
    echo "Copied panel patch to $ext_dir"
  fi

  if [ -f "$SCRIPT_DIR/patches/mounts.patch" ]; then
    cp -f "$SCRIPT_DIR/patches/mounts.patch" "$ext_dir/"
    echo "Copied Wings patch to $ext_dir"
  fi
}

install_panel_patch
install_extension_patch_files

DO_WINGS=0
if [ -n "${WINGS_DIRECTORY:-}" ]; then
  DO_WINGS=1
fi

if [ "$DO_WINGS" -eq 0 ]; then
  if ask_yes_no "Do you have wings on the same machine? If yes, Wings will be downloaded, patched and restarted. Your original wings binary will be backed up to /usr/local/bin/wings and will be restored upon removal of AutoMountSupport." N; then
    DO_WINGS=1
  fi
fi

if [ "$DO_WINGS" -eq 1 ]; then
  if [ -z "${WINGS_DIRECTORY:-}" ]; then
    if [ -x "/usr/local/bin/wings" ]; then
      WINGS_DIRECTORY="/usr/local/bin"
      echo "Using /usr/local/bin as Wings directory."
    else
      WINGS_DIRECTORY="$(prompt_directory 'Enter the Wings installation directory')"
    fi
  fi

  if [ ! -d "$WINGS_DIRECTORY" ]; then
    echo "ERROR: Wings directory does not exist: $WINGS_DIRECTORY"
    exit 1
  fi

  install_wings_patch "$WINGS_DIRECTORY"
else
  echo "Please make sure to run the included AutoMount-Wings-Install.sh on any machines with wings"
fi
