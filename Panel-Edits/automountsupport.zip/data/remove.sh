#!/bin/sh
set -e

if [ -z "${PTERODACTYL_DIRECTORY:-}" ]; then
  echo "ERROR: PTERODACTYL_DIRECTORY is not set."
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PATCH_FILE="$SCRIPT_DIR/patches/automount-buttons.patch"
WING_BACKUP_SUFFIX=".automount-backup"

find_wings_patch() {
  if [ -n "${WING_PATCH_FILE:-}" ] && [ -f "${WING_PATCH_FILE}" ]; then
    printf '%s' "$WING_PATCH_FILE"
    return 0
  fi

  if [ -n "${PTERODACTYL_DIRECTORY:-}" ]; then
    candidate="$PTERODACTYL_DIRECTORY/.blueprint/extensions/automountsupport/private/patches/mounts.patch"
    if [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
  fi

  dir="$SCRIPT_DIR"
  while [ "$dir" != "/" ] && [ -n "$dir" ]; do
    candidate="$dir/.blueprint/dev/automountsupport/data/patches/mounts.patch"
    if [ -f "$candidate" ]; then
      printf '%s' "$candidate"
      return 0
    fi
    dir="$(dirname "$dir")"
  done

  return 1
}

WING_PATCH_FILE="$(find_wings_patch)"

ask_yes_no() {
  prompt="$1"
  default="$2"

  while true; do
    if [ -t 0 ]; then
      if [ "$default" = "Y" ]; then
        printf "%s [Y/n] " "$prompt"
      else
        printf "%s [y/N] " "$prompt"
      fi
      if ! IFS= read -r answer; then
        answer=""
      fi
    else
      answer=""
    fi

    case "$answer" in
      y|Y|yes|Yes|YES)
        return 0
        ;;
      n|N|no|No|NO)
        return 1
        ;;
      "")
        if [ "$default" = "Y" ]; then
          return 0
        fi
        return 1
        ;;
      *)
        echo "Please answer yes or no."
        ;;
    esac
  done
}

prompt_directory() {
  prompt="$1"

  while true; do
    printf "%s: " "$prompt"
    if ! IFS= read -r dir; then
      return 1
    fi
    if [ -z "$dir" ]; then
      echo "Please enter a directory path."
      continue
    fi
    if [ -d "$dir" ]; then
      printf '%s' "$dir"
      return 0
    fi
    echo "Directory does not exist: $dir"
  done
}

reverse_patch_file() {
  patch_file="$1"
  if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    if git apply --reverse --ignore-whitespace "$patch_file"; then
      return 0
    fi
  fi

  if command -v patch >/dev/null 2>&1; then
    patch --ignore-whitespace -p1 --batch --reverse < "$patch_file"
    return $?
  fi

  return 1
}

remove_panel_patch() {
  if [ ! -f "$PATCH_FILE" ]; then
    echo "ERROR: Patch file not found: $PATCH_FILE"
    exit 1
  fi

  cd "$PTERODACTYL_DIRECTORY"

  if reverse_patch_file "$PATCH_FILE"; then
    echo "Panel patch removed successfully."
  else
    echo "ERROR: git or patch is required to remove the extension patch."
    exit 1
  fi
}

restore_wings_binary() {
  wings_dir="$1"
  backup_file="$wings_dir/wings$WING_BACKUP_SUFFIX"

  if [ -f "$backup_file" ]; then
    cp -pf "$backup_file" "$wings_dir/wings"
    rm -f "$backup_file"
    echo "Restored Wings binary from $backup_file"
  else
    echo "WARNING: Backup file not found: $backup_file"
  fi
}

remove_panel_patch

wings_installation_detected() {
  if [ -n "${WINGS_DIRECTORY:-}" ] && [ -d "$WINGS_DIRECTORY" ] && [ -f "$WINGS_DIRECTORY/wings" ]; then
    return 0
  fi
  return 1
}

DO_WINGS=0
if wings_installation_detected; then
  DO_WINGS=1
fi

if [ "$DO_WINGS" -eq 0 ]; then
  if ask_yes_no "Do you want to remove the Wings patch and restore the Wings binary on this machine?" N; then
    DO_WINGS=1
  fi
fi

if [ "$DO_WINGS" -eq 1 ]; then
  if [ -z "${WINGS_DIRECTORY:-}" ]; then
    WINGS_DIRECTORY="$(prompt_directory 'Enter the Wings installation directory')"
  fi

  if [ ! -d "$WINGS_DIRECTORY" ]; then
    echo "Wings directory does not exist: $WINGS_DIRECTORY"
    echo "No Wings installation detected, skipping Wings cleanup."
    exit 0
  fi

  if [ ! -f "$WINGS_DIRECTORY/wings" ]; then
    echo "Wings binary not found in $WINGS_DIRECTORY."
    echo "No Wings installation detected, skipping Wings cleanup."
    exit 0
  fi

  if [ ! -f "$WING_PATCH_FILE" ]; then
    echo "ERROR: Wings patch file not found: $WING_PATCH_FILE"
    exit 1
  fi

  cd "$WINGS_DIRECTORY"
  if reverse_patch_file "$WING_PATCH_FILE"; then
    echo "Wings patch removed successfully."
  else
    echo "WARNING: Could not remove Wings patch."
  fi

  restore_wings_binary "$WINGS_DIRECTORY"
fi
