@extends('layouts.admin')

@section('title')
    Dropdown Variable Support
@endsection

@section('content-header')
    <h1>Dropdown Variable Support <small>Blueprint extension information</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Dropdown Variable Support</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        <div class="col-md-8">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Extension Description</h3>
                </div>
                <div class="box-body">
                    <p>This extension adds dropdown option support for egg variables and startup variables.</p>
                    <p>If you see this page, the extension manifest has loaded correctly.</p>
                </div>
            </div>
        </div>
    </div>
@endsection
