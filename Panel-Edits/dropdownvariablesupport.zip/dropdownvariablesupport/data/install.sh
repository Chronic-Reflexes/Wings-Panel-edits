#!/bin/sh
set -e

if [ -z "${PTERODACTYL_DIRECTORY:-}" ]; then
  echo "ERROR: PTERODACTYL_DIRECTORY is not set."
  exit 1
fi

cd "$PTERODACTYL_DIRECTORY"

escape_pattern() {
  printf '%s' "$1" | sed 's/[][\\.^$*+?(){}|\/&]/\\&/g'
}

insert_line_after() {
  file="$1"
  pattern="$2"
  new_line="$3"

  if grep -Fqx "$new_line" "$file" 2>/dev/null; then
    return 0
  fi

  escaped_pattern=$(escape_pattern "$pattern")
  escaped_line=$(escape_pattern "$new_line")
  sed -i "0,/$escaped_pattern/{s/$escaped_pattern/&\n$escaped_line/}" "$file"
}

insert_line_before() {
  file="$1"
  pattern="$2"
  new_line="$3"

  if grep -Fqx "$new_line" "$file" 2>/dev/null; then
    return 0
  fi

  escaped_pattern=$(escape_pattern "$pattern")
  escaped_line=$(escape_pattern "$new_line")
  sed -i "0,/$escaped_pattern/{s/$escaped_pattern/$escaped_line\n&/}" "$file"
}

insert_block_after() {
  file="$1"
  start_pattern="$2"
  marker="$3"

  if [ -n "$marker" ] && grep -Fq "$marker" "$file" 2>/dev/null; then
    return 0
  fi

  current_pattern="$start_pattern"
  while IFS= read -r line; do
    insert_line_after "$file" "$current_pattern" "$line"
    current_pattern="$line"
  done
}

insert_block_before() {
  file="$1"
  end_pattern="$2"
  marker="$3"

  if [ -n "$marker" ] && grep -Fq "$marker" "$file" 2>/dev/null; then
    return 0
  fi

  current_pattern="$end_pattern"
  first=1
  while IFS= read -r line; do
    if [ "$first" -eq 1 ]; then
      insert_line_before "$file" "$current_pattern" "$line"
      current_pattern="$line"
      first=0
    else
      insert_line_after "$file" "$current_pattern" "$line"
      current_pattern="$line"
    fi
  done
}

create_migration_file() {
  local migrations_dir="$PTERODACTYL_DIRECTORY/database/migrations"
  local migration_file="$migrations_dir/2026_05_07_000000_add_egg_variable_dropdown_options.php"

  mkdir -p "$migrations_dir"

  if [ -f "$migration_file" ]; then
    return 0
  fi

  cat > "$migration_file" <<'EOF'
<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddEggVariableDropdownOptions extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('egg_variables', function (Blueprint $table) {
            $table->text('dropdown_options')->nullable()->after('rules');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('egg_variables', function (Blueprint $table) {
            $table->dropColumn('dropdown_options');
        });
    }
}
EOF
}

install_panel_patch() {
  insert_line_after "app/Models/EggVariable.php" " * @property ServerVariable \$serverVariable" " * @property array|null \$dropdown_options"
  insert_line_after "app/Models/EggVariable.php" "        'user_viewable' => 'bool'," "        'dropdown_options' => 'array',"
  insert_line_after "app/Models/EggVariable.php" "        'user_viewable' => 'boolean'," "        'dropdown_options' => 'array',"
  insert_line_after "app/Models/EggVariable.php" "        'user_viewable' => 0," "        'dropdown_options' => '[]',"

  insert_block_after "app/Http/Requests/Admin/Egg/EggVariableFormRequest.php" "            'options' => 'sometimes|required|array'," "DropdownVariableSupport FormRequest" <<'EOF'
            'dropdown_options' => 'sometimes|nullable|array',
            'dropdown_options.*' => 'required|string|max:1024',
            'dropdown_options_present' => 'sometimes',
EOF

  insert_block_after "app/Services/Eggs/Variables/VariableCreationService.php" "        $options = array_get(\$data, 'options') ?? []" "DropdownVariableSupport VariableCreationService" <<'EOF'
        // DropdownVariableSupport BEGIN: normalize dropdown options for creation
        $dropdownOptions = array_values(array_filter(array_map(static function ($dropdownOption) {
            if (is_array($dropdownOption)) {
                $label = trim((string) array_get($dropdownOption, 'label', ''));
                $value = trim((string) array_get($dropdownOption, 'value', $label));
            } elseif (is_scalar($dropdownOption)) {
                $decoded = json_decode((string) $dropdownOption, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $label = trim((string) array_get($decoded, 'label', ''));
                    $value = trim((string) array_get($decoded, 'value', $label));
                } else {
                    $label = trim((string) $dropdownOption);
                    $value = $label;
                }
            } else {
                return null;
            }

            if ($label === '' && $value === '') {
                return null;
            }

            if ($label === '') {
                $label = $value;
            }

            if ($value === '') {
                $value = $label;
            }

            return ['label' => $label, 'value' => $value];
        }, array_get($data, 'dropdown_options') ?? []), static function ($dropdownOption) {
            return !is_null($dropdownOption);
        }));
        // DropdownVariableSupport END: normalize dropdown options for creation
EOF

  insert_line_after "app/Services/Eggs/Variables/VariableCreationService.php" "            'rules' => \$data['rules'] ?? ''," "            'dropdown_options' => \$dropdownOptions,"

  insert_block_after "app/Services/Eggs/Variables/VariableUpdateService.php" "        $options = array_get(\$data, 'options') ?? []" "DropdownVariableSupport VariableUpdateService" <<'EOF'
        // DropdownVariableSupport BEGIN: normalize dropdown options for update
        $hasDropdownOptions = array_key_exists('dropdown_options_present', $data);
        $dropdownOptions = $hasDropdownOptions ? array_values(array_filter(array_map(static function ($dropdownOption) {
            if (is_array($dropdownOption)) {
                $label = trim((string) array_get($dropdownOption, 'label', ''));
                $value = trim((string) array_get($dropdownOption, 'value', $label));
            } elseif (is_scalar($dropdownOption)) {
                $decoded = json_decode((string) $dropdownOption, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $label = trim((string) array_get($dropdownOption, 'label', ''));
                    $value = trim((string) array_get($dropdownOption, 'value', $label));
                } else {
                    $label = trim((string) $dropdownOption);
                    $value = $label;
                }
            } else {
                return null;
            }

            if ($label === '' && $value === '') {
                return null;
            }

            if ($label === '') {
                $label = $value;
            }

            if ($value === '') {
                $value = $label;
            }

            return ['label' => $label, 'value' => $value];
        }, array_get($data, 'dropdown_options') ?? []), static function ($dropdownOption) {
            return !is_null($dropdownOption);
        })) : array_values(array_filter(array_map(static function ($dropdownOption) {
            if (is_array($dropdownOption)) {
                $label = trim((string) array_get($dropdownOption, 'label', ''));
                $value = trim((string) array_get($dropdownOption, 'value', $label));
            } elseif (is_scalar($dropdownOption)) {
                $decoded = json_decode((string) $dropdownOption, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $label = trim((string) array_get($dropdownOption, 'label', ''));
                    $value = trim((string) array_get($dropdownOption, 'value', $label));
                } else {
                    $label = trim((string) $dropdownOption);
                    $value = $label;
                }
            } else {
                return null;
            }

            if ($label === '' && $value === '') {
                return null;
            }

            if ($label === '') {
                $label = $value;
            }

            if ($value === '') {
                $value = $label;
            }

            return ['label' => $label, 'value' => $value];
        }, $variable->dropdown_options ?? []), static function ($dropdownOption) {
            return !is_null($dropdownOption);
        }));
        // DropdownVariableSupport END: normalize dropdown options for update
EOF

  insert_line_after "app/Services/Eggs/Variables/VariableUpdateService.php" "            'rules' => \$data['rules'] ?? ''," "            'dropdown_options' => \$dropdownOptions,"

  insert_block_after "app/Transformers/Api/Client/EggVariableTransformer.php" "            'is_editable' => \$variable->user_editable," "DropdownVariableSupport EggVariableTransformer" <<'EOF'
            // DropdownVariableSupport BEGIN: normalize dropdown options for transformer output
            'dropdown_options' => collect($variable->dropdown_options ?? [])->map(function ($dropdownOption) {
                if (is_array($dropdownOption)) {
                    $label = trim((string) array_get($dropdownOption, 'label', ''));
                    $value = trim((string) array_get($dropdownOption, 'value', $label));
                } elseif (is_scalar($dropdownOption)) {
                    $decoded = json_decode((string) $dropdownOption, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                        $label = trim((string) array_get($dropdownOption, 'label', ''));
                        $value = trim((string) array_get($dropdownOption, 'value', $label));
                    } else {
                        $label = trim((string) $dropdownOption);
                        $value = $label;
                    }
                } else {
                    return null;
                }

                if ($label === '' && $value === '') {
                    return null;
                }

                if ($label === '') {
                    $label = $value;
                }

                if ($value === '') {
                    $value = $label;
                }

                return ['label' => $label, 'value' => $value];
            })->filter(function ($dropdownOption) {
                return !is_null($dropdownOption);
            })->values()->all(),
            // DropdownVariableSupport END: normalize dropdown options for transformer output
EOF

  create_migration_file

  insert_block_after "resources/views/admin/eggs/variables.blade.php" "                              <p class=\"text-muted small\">These rules are defined using standard <a href=\"https://laravel.com/docs/5.7/validation#available-validation-rules\" target=\"_blank\">Laravel Framework validation rules</a>.</p>" "DropdownVariableSupport edit variable dropdowns" <<'EOF'
                        <!-- DropdownVariableSupport BEGIN: existing dropdown variable container -->
                        <input type="hidden" name="dropdown_options_present" value="1" />
                        <div id="existingVariableDropdownItemsContainer-{{ $variable->id }}" class="hidden">
                            @foreach(collect($variable->dropdown_options ?? [])->map(function ($dropdownOption) {
                                if (is_array($dropdownOption)) {
                                    $label = trim((string) array_get($dropdownOption, 'label', ''));
                                    $value = trim((string) array_get($dropdownOption, 'value', $label));
                                } elseif (is_scalar($dropdownOption)) {
                                    $decoded = json_decode((string) $dropdownOption, true);
                                    if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                                        $label = trim((string) array_get($dropdownOption, 'label', ''));
                                        $value = trim((string) array_get($dropdownOption, 'value', $label));
                                    } else {
                                        $label = trim((string) $dropdownOption);
                                        $value = $label;
                                    }
                                } else {
                                    return null;
                                }

                                if ($label === '' && $value === '') {
                                    return null;
                                }

                                if ($label === '') {
                                    $label = $value;
                                }

                                if ($value === '') {
                                    $value = $label;
                                }

                                return ['label' => $label, 'value' => $value];
                            })->filter(function ($dropdownOption) {
                                return !is_null($dropdownOption);
                            })->values() as $dropdownOption)
                                <div class="dropdown-option-item">
                                    <input type="hidden" name="dropdown_options[]" class="dropdown-option-value" value="{{ json_encode($dropdownOption) }}" />
                                </div>
                            @endforeach
                        </div>
                        <!-- DropdownVariableSupport END: existing dropdown variable container -->
EOF

  insert_line_after "resources/views/admin/eggs/variables.blade.php" "                              {!! csrf_field() !!}" "                        <button class=\"btn btn-sm btn-info pull-right open-edit-dropdown-modal\" type=\"button\" data-toggle=\"modal\" data-target=\"#editDropdownModal\" data-variable-id=\"{{ \$variable->id }}\" style=\"margin-right: 5px;\">Dropdowns</button>"

  insert_block_after "resources/views/admin/eggs/variables.blade.php" "                              <p class=\"text-muted small\">These rules are defined using standard <a href=\"https://laravel.com/docs/5.7/validation#available-validation-rules\" target=\"_blank\">Laravel Framework validation rules</a>.</p>" "DropdownVariableSupport create variable dropdowns" <<'EOF'
                    <!-- DropdownVariableSupport BEGIN: create variable dropdown summary -->
                    <div class="form-group">
                        <label class="control-label">Dropdown Variables</label>
                        <div id="newVariableDropdownItemsContainer" class="hidden"></div>
                        <p class="text-muted small">Manage dropdown variables in the popup below. These values will be included when this variable is created.</p>
                    </div>
                    <!-- DropdownVariableSupport END: create variable dropdown summary -->
EOF

  insert_line_before "resources/views/admin/eggs/variables.blade.php" "                              <button type=\"submit\" class=\"btn btn-primary\">Create Variable</button>" "                    <button type=\"button\" class=\"btn btn-info pull-right open-create-dropdown-modal\" style=\"margin-right: 5px; min-width: 150px;\" data-toggle=\"modal\" data-target=\"#createDropdownModal\">Dropdown Options</button>"

  insert_block_before "resources/views/admin/eggs/variables.blade.php" "  @endsection" "DropdownVariableSupport dropdown modals" <<'EOF'
<!-- DropdownVariableSupport BEGIN: dropdown modals -->
<div class="modal fade" id="createDropdownModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Create Dropdown Variables</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="control-label">Dropdown Variables</label>
                    <div id="createDropdownItemsContainer"></div>
                    <button type="button" class="btn btn-xs btn-default" id="addCreateDropdownItem">Create Dropdown Variable</button>
                    <p class="text-muted small">Add dropdown variables in this popup and save them back into the create variable form.</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveCreateDropdownItems">Save</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editDropdownModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Dropdown Variables</h4>
                <p class="text-muted small" style="margin-top: 8px; margin-bottom: 0;">Manage the dropdown values used for this existing variable.</p>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="control-label">Dropdown Variables</label>
                    <div id="editDropdownItemsContainer"></div>
                    <button type="button" class="btn btn-xs btn-default" id="addEditDropdownItem">Add Dropdown Variable</button>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveEditDropdownItems">Save</button>
            </div>
        </div>
    </div>
</div>
<!-- DropdownVariableSupport END: dropdown modals -->
EOF

  insert_block_before "resources/views/admin/eggs/variables.blade.php" "         $('.pOptions').select2();" "DropdownVariableSupport dropdown scripts" <<'EOF'
        <!-- DropdownVariableSupport BEGIN: dropdown option helper scripts -->
        function escapeDropdownValue(value = '') {
            return $("<div/>").text(value).html();
        }

        function normalizeDropdownOption(option = null) {
            if (option === undefined || option === null) {
                return null;
            }

            let title = '';
            let variable = '';

            if (typeof option === 'object' && !Array.isArray(option)) {
                title = ((option.label ?? option.title) ?? '').toString().trim();
                variable = ((option.value ?? option.variable) ?? '').toString().trim();
            } else {
                title = option.toString().trim();
                variable = title;
            }

            if (title.length === 0 && variable.length === 0) {
                return null;
            }

            if (title.length === 0) {
                title = variable;
            }

            if (variable.length === 0) {
                variable = title;
            }

            return { label: title, value: variable };
        }

        function parseDropdownOption(value = '') {
            if (value === undefined || value === null) {
                return null;
            }

            const trimmed = value.toString().trim();
            if (!trimmed.length) {
                return null;
            }

            try {
                return normalizeDropdownOption(JSON.parse(trimmed));
            } catch (error) {
                return normalizeDropdownOption(trimmed);
            }
        }

        function encodeDropdownOption(option = null) {
            const normalized = normalizeDropdownOption(option);
            return normalized ? JSON.stringify(normalized) : '';
        }

        function formatDropdownOptionSummary(option = null) {
            const normalized = normalizeDropdownOption(option);
            if (!normalized) {
                return 'New Dropdown Variable';
            }

            return normalized.label === normalized.value ? normalized.label : `${normalized.label} -> ${normalized.value}`;
        }

        function getDropdownModalItemOption(item) {
            const titleInput = item.find('.dropdown-option-summary-text');
            const title = titleInput.prop('readonly')
                ? (item.data('dropdownTitle') || '').toString().trim()
                : (titleInput.val() || '').toString().trim();
            const variable = (item.find('.dropdown-option-variable-input').val() || '').toString().trim();

            return normalizeDropdownOption({ label: title, value: variable });
        }

        function refreshDropdownModalItem(item) {
            const editor = item.find('.dropdown-option-editor');
            const titleInput = item.find('.dropdown-option-summary-text');
            const variableInput = item.find('.dropdown-option-variable-input');
            const option = getDropdownModalItemOption(item);

            item.data('dropdownTitle', option ? option.label : '');
            titleInput.prop('readonly', !editor.is(':visible'));
            titleInput.attr('placeholder', editor.is(':visible') ? 'Title' : '');
            titleInput.val(editor.is(':visible') ? (option ? option.label : '') : formatDropdownOptionSummary(option));
            variableInput.attr('placeholder', 'Variable');
            variableInput.val(option && option.value !== option.label ? option.value : '');
        }

        function buildDropdownModalItem(option = null, expanded = false) {
            const normalized = normalizeDropdownOption(option) || { label: '', value: '' };
            const editor = $('<div class="dropdown-option-editor" style="display: none; margin-top: 5px;">')
                .append('<input type="text" class="form-control dropdown-option-variable-input" placeholder="Variable" value="' + escapeDropdownValue(normalized.value === normalized.label ? '' : normalized.value) + '" />');

            const item = $('<div class="dropdown-option-item" style="margin-bottom: 5px;">')
                .data('dropdownTitle', normalized.label)
                .append(
                    $('<div class="input-group">')
                        .append('<input type="text" class="form-control dropdown-option-summary-text" readonly value="' + escapeDropdownValue(formatDropdownOptionSummary(normalized)) + '" />')
                        .append('<span class="input-group-btn"><button type="button" class="btn btn-default toggle-dropdown-item">Edit</button><button type="button" class="btn btn-danger remove-dropdown-item">Remove</button></span>')
                )
                .append(editor);

            if (expanded) {
                editor.show();
                item.find('.toggle-dropdown-item').text('Hide');
            }

            refreshDropdownModalItem(item);

            return item;
        }

        function buildDropdownHiddenItem(option = null) {
            const encoded = encodeDropdownOption(option);
            return $("<div class=\"dropdown-option-item\">")
                .append(
                    $('<input type="hidden" name="dropdown_options[]" class="dropdown-option-value" />').val(encoded)
                );
        }

        $('#createDropdownModal').on('show.bs.modal', function () {
            const target = $('#createDropdownItemsContainer').empty();
            $('#newVariableDropdownItemsContainer .dropdown-option-value').each(function () {
                const option = parseDropdownOption($(this).val());
                if (option) {
                    target.append(buildDropdownModalItem(option));
                }
            });
        });

        $('#addCreateDropdownItem').on('click', function () {
            $('#createDropdownItemsContainer').append(buildDropdownModalItem(null, true));
        });

        $('#saveCreateDropdownItems').on('click', function () {
            const target = $('#newVariableDropdownItemsContainer').empty();
            $('#createDropdownItemsContainer .dropdown-option-item').each(function () {
                const option = getDropdownModalItemOption($(this));
                if (option) {
                    target.append(buildDropdownHiddenItem(option));
                }
            });
            $('#createDropdownModal').modal('hide');
        });

        $('#editDropdownModal').on('show.bs.modal', function (event) {
            const button = $(event.relatedTarget);
            const variableId = button.data('variableId');
            const source = $('#existingVariableDropdownItemsContainer-' + variableId);
            const target = $('#editDropdownItemsContainer').empty();

            $(this).data('sourceContainer', source);

            source.find('.dropdown-option-value').each(function () {
                const option = parseDropdownOption($(this).val());
                if (option) {
                    target.append(buildDropdownModalItem(option));
                }
            });
        });

        $('#addEditDropdownItem').on('click', function () {
            $('#editDropdownItemsContainer').append(buildDropdownModalItem(null, true));
        });

        $('#saveEditDropdownItems').on('click', function () {
            const source = $('#editDropdownModal').data('sourceContainer');
            if (!source || !source.length) {
                return;
            }

            source.empty();
            $('#editDropdownItemsContainer .dropdown-option-item').each(function () {
                const option = getDropdownModalItemOption($(this));
                if (option) {
                    source.append(buildDropdownHiddenItem(option));
                }
            });

            $('#editDropdownModal').modal('hide');
            const form = source.closest('form');
            form.find('input[data-dropdown-method="true"]').remove();
            form.append('<input type="hidden" name="_method" value="PATCH" data-dropdown-method="true" />');
            form.trigger('submit');
        });

        $('#createDropdownItemsContainer, #editDropdownItemsContainer').on('click', '.remove-dropdown-item', function () {
            $(this).closest('.dropdown-option-item').remove();
        });

        $('#createDropdownItemsContainer, #editDropdownItemsContainer').on('click', '.toggle-dropdown-item', function () {
            const item = $(this).closest('.dropdown-option-item');
            const editor = item.find('.dropdown-option-editor');
            const isVisible = editor.is(':visible');
            editor.toggle(!isVisible);
            $(this).text(isVisible ? 'Edit' : 'Hide');
            refreshDropdownModalItem(item);

            if (!isVisible) {
                item.find('.dropdown-option-summary-text').trigger('focus');
            }
        });

        $('#createDropdownItemsContainer, #editDropdownItemsContainer').on('input', '.dropdown-option-summary-text, .dropdown-option-variable-input', function () {
            refreshDropdownModalItem($(this).closest('.dropdown-option-item'));
        });
        <!-- DropdownVariableSupport END: dropdown option helper scripts -->
EOF

  echo "DropdownVariableSupport panel patch installed successfully."
}

install_panel_patch
exit 0
