#!/bin/sh
set -e

if [ -z "${PTERODACTYL_DIRECTORY:-}" ]; then
  echo "ERROR: PTERODACTYL_DIRECTORY is not set."
  exit 1
fi

cd "$PTERODACTYL_DIRECTORY"

escape_pattern() {
  printf '%s' "$1" | sed 's/[][\\.^$*+?(){}|\/&]/\\&/g'
}

remove_line() {
  file="$1"
  line="$2"

  escaped_line=$(escape_pattern "$line")
  sed -i "/^$escaped_line\$/d" "$file"
}

remove_block_by_markers() {
  file="$1"
  start_marker="$2"
  end_marker="$3"

  if grep -Fq "$start_marker" "$file" 2>/dev/null; then
    escaped_start=$(escape_pattern "$start_marker")
    escaped_end=$(escape_pattern "$end_marker")
    sed -i "/$escaped_start/,/$escaped_end/d" "$file"
  fi
}

remove_panel_patch() {
  remove_line "app/Models/EggVariable.php" " * @property array|null \$dropdown_options"
  remove_line "app/Models/EggVariable.php" "        'dropdown_options' => 'array',"
  remove_line "app/Models/EggVariable.php" "        'dropdown_options' => '[]',"

  remove_line "app/Http/Requests/Admin/Egg/EggVariableFormRequest.php" "            'dropdown_options' => 'sometimes|nullable|array',"
  remove_line "app/Http/Requests/Admin/Egg/EggVariableFormRequest.php" "            'dropdown_options.*' => 'required|string|max:1024',"
  remove_line "app/Http/Requests/Admin/Egg/EggVariableFormRequest.php" "            'dropdown_options_present' => 'sometimes',"

  remove_block_by_markers "app/Services/Eggs/Variables/VariableCreationService.php" "        // DropdownVariableSupport BEGIN: normalize dropdown options for creation" "        // DropdownVariableSupport END: normalize dropdown options for creation"
  remove_line "app/Services/Eggs/Variables/VariableCreationService.php" "            'dropdown_options' => \$dropdownOptions,"

  remove_block_by_markers "app/Services/Eggs/Variables/VariableUpdateService.php" "        // DropdownVariableSupport BEGIN: normalize dropdown options for update" "        // DropdownVariableSupport END: normalize dropdown options for update"
  remove_line "app/Services/Eggs/Variables/VariableUpdateService.php" "            'dropdown_options' => \$dropdownOptions,"

  remove_block_by_markers "app/Transformers/Api/Client/EggVariableTransformer.php" "            // DropdownVariableSupport BEGIN: normalize dropdown options for transformer output" "            // DropdownVariableSupport END: normalize dropdown options for transformer output"

  remove_block_by_markers "resources/views/admin/eggs/variables.blade.php" "                        <!-- DropdownVariableSupport BEGIN: existing dropdown variable container -->" "                        <!-- DropdownVariableSupport END: existing dropdown variable container -->"
  remove_line "resources/views/admin/eggs/variables.blade.php" "                        <button class=\"btn btn-sm btn-info pull-right open-edit-dropdown-modal\" type=\"button\" data-toggle=\"modal\" data-target=\"#editDropdownModal\" data-variable-id=\"{{ \$variable->id }}\" style=\"margin-right: 5px;\">Dropdowns</button>"
  remove_block_by_markers "resources/views/admin/eggs/variables.blade.php" "                    <!-- DropdownVariableSupport BEGIN: create variable dropdown summary -->" "                    <!-- DropdownVariableSupport END: create variable dropdown summary -->"
  remove_line "resources/views/admin/eggs/variables.blade.php" "                    <button type=\"button\" class=\"btn btn-info pull-right open-create-dropdown-modal\" style=\"margin-right: 5px; min-width: 150px;\" data-toggle=\"modal\" data-target=\"#createDropdownModal\">Dropdown Options</button>"
  remove_block_by_markers "resources/views/admin/eggs/variables.blade.php" "<!-- DropdownVariableSupport BEGIN: dropdown modals -->" "<!-- DropdownVariableSupport END: dropdown modals -->"
  remove_block_by_markers "resources/views/admin/eggs/variables.blade.php" "<!-- DropdownVariableSupport BEGIN: dropdown option helper scripts -->" "<!-- DropdownVariableSupport END: dropdown option helper scripts -->"

  rm -f "database/migrations/2026_05_07_000000_add_egg_variable_dropdown_options.php"
}

remove_panel_patch

echo "DropdownVariableSupport patch removed successfully."
exit 0
